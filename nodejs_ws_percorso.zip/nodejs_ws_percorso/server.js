const express = require('express');

const server = express()
  .use((req, res) => res.sendFile('/index.html', { root: __dirname }))
  .listen(3000, () => console.log('Listening on 3000'));
  
const { Server } = require('ws');

const ws_server = new Server({ server });

   var b = new Array();
   for(i=0;i<10;i++)
   {
      b[i] = new Array();
      for(j=0;j<2;j++)
      {
	     b[i][j]=0;
      }
   }
   b[0][0]=3;
   b[0][1]=2;
   b[1][0]=3;
   b[1][1]=3;
   b[2][0]=3;
   b[2][1]=4;
   b[3][0]=4;
   b[3][1]=4;
   b[4][0]=5;
   b[4][1]=4;
   b[5][0]=6;
   b[5][1]=4;
   b[6][0]=6;
   b[6][1]=5;
   b[7][0]=6;
   b[7][1]=6;
   b[8][0]=6;
   b[8][1]=7;
   b[9][0]=7;
   b[9][1]=7;

   let conta=0;

ws_server.on('connection', (ws) => { 
   console.log('New client connected!');
   ws.on('close', () => console.log('Client has disconnected!'));
});

setInterval(() => {
  ws_server.clients.forEach((client) => {

      if(conta<9)
      {
	 conta++;
         posx=b[conta][0];
         posy=b[conta][1];
      }
      else
      {
         conta=0;
      }

	  
    let info = {posx: posx, posy: posy }
    const data = JSON.stringify({'info': info});
    client.send(data);
  });
}, 1000);


