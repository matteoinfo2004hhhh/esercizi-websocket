const eser=require('./esercizi.js');

a=3;
b=3;
c=3;

s=eser.maxmin(a,b,c);
console.log(s);

v=new Array();
d="";
for(i=0;i<10;i++) {
  v[i]=Math.round(Math.random()*99)+1;
  d=d+v[i]+" ";
}
console.log(d);
s=eser.ordina(v);
console.log(s);
