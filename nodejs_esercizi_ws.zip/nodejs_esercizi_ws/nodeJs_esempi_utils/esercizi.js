function maxmin(a,b,c)  {
 s="";

 // tutti uguali
 if(a==b && a==c) {
    s=s+"a,b,c uguali ";
 } 
  
 if(a!=c && a!=b && b!=c) 
 {
    // trova 1 max
    if(a>b && a>c) {
       s=s+"a max ";
    } 
    if(b>a && b>c) {
       s=s+"b max ";
    } 
    if(c>a && c>b) {
       s=s+"c max ";
    }
     // trova 1 min 
    if(a<b && a<c) {
       s=s+"a min ";
    } 
    if(b<a && b<c) {
       s=s+"b min ";
    } 
    if(c<a && c<b) {
       s=s+"c min ";
    } 
 }
 else
 {  
    // trova 2 max
    if(a==b && a>c) {
       s=s+"a,b max c min";
    } 
    if(a==c && a>b) {
       s=s+"a,c max b min";
    } 
    if(b==c && b>a) {
       s=s+"b,c max a min";
    }
    // trova 2 min
    if(a==b && a<c) {
       s=s+"c max a,b min";
    } 
    if(a==c && a<b) {
       s=s+"b max a,c min";
    } 
    if(b==c && b<a) {
       s=s+"a max b,c min";
    }
 }
  
 return s;
}

function ordina(vett)  {
  s="";
  
  vett.sort(function(a, b) {
     return a - b;
  });
  
  for(i=0;i<10;i++) {
    s=s+vett[i]+" ";
  }

  return s;
}

module.exports={maxmin,ordina}
