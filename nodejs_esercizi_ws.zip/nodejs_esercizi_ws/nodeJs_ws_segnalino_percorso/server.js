const express = require('express');

const server = express()
  .use((req, res) => res.sendFile('/index.html', { root: __dirname }))
  .listen(3000, () => console.log('Listening on 3000'));
  
const { Server } = require('ws');

const ws_server = new Server({ server });

ws_server.on('connection', (ws) => {
  console.log('New client connected!');
  ws.on('close', () => console.log('Client has disconnected!'));
});

var b = new Array();
for(i=0;i<10;i++)
{
   b[i] = new Array();
   for(j=0;j<2;j++)
   {
      b[i][j]=0;
   }
}

   b[0][0]=30;
   b[0][1]=20;
   
   b[1][0]=30;
   b[1][1]=30;
   
   b[2][0]=30;
   b[2][1]=40;
   
   b[3][0]=40;
   b[3][1]=40;
   
   b[4][0]=50;
   b[4][1]=40;
   
   b[5][0]=60;
   b[5][1]=40;
   
   b[6][0]=60;
   b[6][1]=50;
   
   b[7][0]=60;
   b[7][1]=60;
   
   b[8][0]=60;
   b[8][1]=70;
   
   b[9][0]=70;
   b[9][1]=70;
   
let pos=-1;   
setInterval(() => {
  ws_server.clients.forEach((client) => {
	  
	pos=pos+1;  
	
	if(pos<10) 
	{	
	   x1=b[pos][0];
	   y1=b[pos][1];
	  
	   let position = {x: x1, y: y1}
       const data = JSON.stringify({'position': position});
       client.send(data);
    } 
    else
    {
		pos=0;
    }		
  });
}, 1000);
