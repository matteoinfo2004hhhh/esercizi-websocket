var express = require('express');
var parser = require('body-parser');
var path = require('path');
var app = express();
var ejs = require('ejs');
app.set('view engine','ejs');
app.set('views',path.join(__dirname,'app_views'))

var elenco = [   
    {
       larg: '50',
       alte: '60',
       top: '20',
       left: '30',
       colore: 'blue' 
    },
    {
       larg: '800',
       alte: '30',
       top: '30',
       left: '130',
       colore: 'red' 
    }
]
 
app.get('/',function(req,res){
    res.render('home',{
        visua : elenco
    });
    console.log('user accessing Home page');
});
app.listen(5000,function(){
    console.log('server running on port 5000');
})
